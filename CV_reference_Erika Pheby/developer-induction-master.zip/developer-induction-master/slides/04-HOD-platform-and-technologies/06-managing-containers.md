## Managing Containers

![](images/managing-containers.jpg)