## Clean Code
![](images/clean-code.jpg)