## Encryption

- Use https ([TLS v1.2](https://tools.ietf.org/html/rfc5246)) to encrypt data in motion
- Encrypting data at rest may be necessary