## Semantic links ✖
![](images/semantic-links-cross.jpg)