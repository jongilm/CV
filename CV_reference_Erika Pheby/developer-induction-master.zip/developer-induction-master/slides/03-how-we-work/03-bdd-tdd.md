## BDD and TDD
![](images/bdd-tdd.jpg)