# [Technical Service Requirements](https://github.com/UKHomeOffice/technical-service-requirements)
- services have independent lifecycles
- automated tests
- backwards compatible deployments
