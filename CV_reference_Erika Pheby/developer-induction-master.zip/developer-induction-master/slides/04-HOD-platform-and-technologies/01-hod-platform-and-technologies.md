# HOD Platform and Technologies
How we build and deploy