## Italics ✖
<div style="font-size:0.9em">
<p style="font-style:italic; text-align:left">You may be aware that the same font, at the same point size on a Macintosh "looks smaller" than on most Windows machines.</p>

<p style="font-style:italic; text-align:left">In a nutshell, this is because the "logical resolution" of a Macintosh is 72dpi, while the Windows default is 96dpi.</p>

<p style="font-style:italic; text-align:left">The implications of this are significant. Firstly, it guarantees that it is essentially impossible to have text look identical on Macintoshes and Windows based systems. But if you embrace the adaptability philosophy it doesn't matter.</p>

<p style="font-style:italic; text-align:left">What?</p>

<p style="font-style:italic; text-align:left">If you are concerned about exactly how a web page appears tis is a sign that you still aren't thinking about adaptive pages</p>
</div>