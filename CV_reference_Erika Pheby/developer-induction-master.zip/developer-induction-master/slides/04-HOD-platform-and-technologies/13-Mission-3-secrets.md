## Mission 3! Use a secret in your deployed application
1. Create a kubernetes secret, making sure to template our the secret value in your secret yaml
http://bit.ly/2h2CizD

1. Update your deployment to load in your secret as an environment variable called MYSUPERSECRET
Tutorial follows on from link above