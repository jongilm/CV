## Why do we exist?
### Our aim – to enable delivery teams to deliver higher quality software and services more quickly

note:
We’re still researching how best to do this, but have done a lot already

Generally we will be looking at:
  - Central services, products, libraries, and tooling
  - Supporting projects to use these services, and align to best practice
  - Supporting consistently high quality recruitment