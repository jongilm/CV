## How we operate

1. consultancy (gather feedback)
2. address (documentation, comms, etc.)
3. communicate (training, workshops, etc.)


