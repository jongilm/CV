## Colour ✖
![](images/colour-bad-1.jpg)