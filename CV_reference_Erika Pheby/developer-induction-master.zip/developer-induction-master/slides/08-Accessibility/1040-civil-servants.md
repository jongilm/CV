## 16%
working age adults have a disability
- 8.8% of civil servants
- 45% of adults over state pension age
