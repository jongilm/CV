## Our solution...? Kubernetes

![](images/kubernetes.jpg)