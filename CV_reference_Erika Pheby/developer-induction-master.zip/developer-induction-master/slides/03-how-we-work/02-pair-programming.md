## Pair programming
![](images/pair-programming.jpg)