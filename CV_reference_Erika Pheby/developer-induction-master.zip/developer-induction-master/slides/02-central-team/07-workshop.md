## Workshops

- (On boarding) Dev induction (4 DSAB, Digital Permissions, AFTC, Sponsorship, Proving Things)
  - At least every month
  - Anyone can join
- Advanced DSP workshop (In progress)
- Intro to DSP (IPT, DSAB, Live services, HMPO, RT, GE, EVW, Digital Permissions)
  - AWS office, 2 days, 8hrs