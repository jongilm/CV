## The technology we use
- Java 8, Scala, or Javascript​
- Java – Spring, Dropwizard​
- Scala – Play, Spray​
- Javascript​
  - Back end – node, express​
  - Front end – angular, react​
- Docker
- Kubernetes