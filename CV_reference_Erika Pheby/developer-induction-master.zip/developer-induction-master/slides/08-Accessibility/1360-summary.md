## Summary
- typography style, line height and alignment​
- focus on tabbed elements​
- tab flow and tabindex​
- using alternative text on media​
- semantic links and markup​
- ordering code for screen readers​
- colour contrast​
