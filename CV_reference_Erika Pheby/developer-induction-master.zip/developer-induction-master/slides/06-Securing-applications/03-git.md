## Git
- Don’t put information such as passwords, IP addresses etc. in any repos​
- Sign commits
