## Developing at the Home Office
- [Acceptable use policy​](http://bit.ly/2hrW60L)
- Don't put live data on your personal device​
- Only access live/sensitive data under strict guidance​
- Understand the policies around where you should store your source code​
- [Mandatory data training​](https://civilservicelearning.civilservice.gov.uk/learning-opportunities/responsible-information-general-user-0)
