## Types of impairments
(that affect common use of a website)

- Cognitive
- Motor
- Visual


​