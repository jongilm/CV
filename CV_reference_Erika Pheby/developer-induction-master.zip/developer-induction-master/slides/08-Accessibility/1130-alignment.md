## Line height and alignment ✖
<p style="line-height:3em; text-align:left; font-size:0.75em; border: 1px solid black">The first duty of the government is to keep citizens safe and the country secure. The Home Office has been at the front line of this endeavour since 1782. As such, the Home Office plays a fundamental role in the security and economic prosperity of the United Kingdom.
</p>
<p style="text-align:justify; font-size:0.75em; border: 1px solid black">The first duty of the government is to keep citizens safe and the country secure. The Home Office has been at the front line of this endeavour since 1782. As such, the Home Office plays a fundamental role in the security and economic prosperity of the United Kingdom.
</p>

note:
first one is too much space between lines, so its hard to know its a paragraph or a connected sentence.

second one is fully justified text which is hard to read especially when its wide (not a thin newspaper column)