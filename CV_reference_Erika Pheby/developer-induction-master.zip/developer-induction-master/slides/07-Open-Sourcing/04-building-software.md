## Building software

"Make all new source code open and reusable, and publish it under appropriate licences (or give a convincing explanation as to why this can't be done for specific subsets of the source code)"

[Digital Service Standard #8](https://www.gov.uk/service-manual/service-standard#criterion-8)
