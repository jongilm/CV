## Mission 1! Getting started with Docker

1. Complete the docker getting started tutorial​
https://docs.docker.com/engine/getstarted/​

1. Dockerise a simple NodeJS application (you can use one of your own applications if you like!)​
https://github.com/UKHomeOffice/node-hello-world ​