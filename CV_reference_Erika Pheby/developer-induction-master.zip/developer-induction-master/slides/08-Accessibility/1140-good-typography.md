## Better example of typography ✔

<div style="text-align:left; padding:1em; font-size:0.75em; border: 1px solid black">
<p>The first duty of the government is to keep citizens safe and the country secure. The Home Office has been at the front line of this endeavour since 1782. As such, the Home Office plays a fundamental role in the security and economic prosperity of the United Kingdom.</p>

<p>The Home Office is the lead government department for immigration and passports, drugs policy, crime, fire, counter-terrorism and police.</p>
</div>
