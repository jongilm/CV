## Everything I just told you is wrong
(but it's the best numbers we've got right now)


#### Registered disability != Accessibility need

note:
- Registering or even self identifying is quite different to just having a need.
- Doesn't necessarily affect how they interact how they'll with your web service.
- An accessibility need could be a potentially temporary impairment, like not having put on your glasses to broken bones
