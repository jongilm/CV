## Choosing software
"Where appropriate, government will procure open source solutions. When used in conjunction with compulsory open 
standards, open source presents significant opportunities for the design and delivery of interoperable solutions"

[Government ICT Strategy](https://www.gov.uk/government/uploads/system/uploads/attachment_data/file/85968/uk-government-government-ict-strategy_0.pdf)