## What is Kubernetes

Kubernetes is an open source container cluster manager by Google. It aims to provide a platform for automating 
deployment, scaling, and operations of application containers across clusters of hosts.​
