## Google Gruyere​

- A sandboxed, test environment (to store notes about cheese) to get a better understanding of common vulnerabilities​
- https://google-gruyere.appspot.com​
- Practice exploiting:​
  - XSS​
  - Injection​
  - CSRF​
  - cookie manipulation​
  - elevation of privilege​
  - path traversal​
  - ajax vulnerabilities... and more!​