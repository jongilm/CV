## Mission 2! Deploy an application to kubernetes
Make sure you have completed the developer getting started guide!​ http://bit.ly/2gEJ2IK

1. Run a Kubernetes cluster locally with minikube and deploy a sample application to it http://bit.ly/2gIf0Cb

1. Use kd to deploy your application in one line​ https://github.com/UKHomeOffice/kd​

1. Deploy a sample application to the DSP​ http://bit.ly/2hbs3hj

1. Delete everything you have deployed!​