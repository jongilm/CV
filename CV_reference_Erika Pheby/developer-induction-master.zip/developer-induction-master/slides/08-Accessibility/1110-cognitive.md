## Cognitive - distractions

<div style="text-align:right; display:block; width:50%; float:left">Don't put text you want people to read next to something that could be distracting</div>

<div style="display:block; float:left;">
![Animated gif](images/distraction.gif)
</div>

note:
People with ADHD may have a hard time focusing on text when there is something attention grabbing next to it