## Some more tools worth knowing about

- Nginx with Naxsi - standard image for HO
  - https://github.com/UKHomeOffice/docker-nginx-proxy
- Standard base images
  - http://bit.ly/2fW70fh
- Keycloak
  - Keycloak central service
    - http://keycloak.digital.homeoffice.gov.uk/
  - keycloak-proxy docker image
    - https://github.com/gambol99/keycloak-proxy/