## And the Home Office's stance...?

![](images/open-by-default.jpg)
