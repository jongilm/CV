## Keyboard - TABINDEX fixed

<video class="stretch" controls type="video/mp4" src="/media/tabbing2.mp4">[A video of tabbing fix](https://www.youtube.com/v/6lJ70HH9JHY)
</video>