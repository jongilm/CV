## Branching
- Protect your master branch​
  - No force pushing to master​
  - Reviews required on PRs before they can be merged​
- Develop each story on a new branch​
- Rebase/merge from master regularly to avoid merge hell​