## The HO technology stack
More detail on the technology stack is kept on trello, showing which technologies we are investing in and which are on
their way out

http://bit.ly/2eXqPjG

Note you will need to request access from the central team to be able to view this