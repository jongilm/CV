## Expectations
- Understand the platform​
- Responsible for security​
- Responsible for documentation​
- Collaborating with others to complete stories
- Reach out to other teams, identify opportunities to share best practice and re-use components​
- Publicise libraries and services​
- Up to 20% of time on non-project work​
- Participate in away days​