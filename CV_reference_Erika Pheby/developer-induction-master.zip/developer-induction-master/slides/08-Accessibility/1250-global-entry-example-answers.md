![](images/global-entry-example-small.jpg)

- ✖ No alt text
- ✖ `alt="Image of UK Flag"`
- ✔ Empty alt attribute `alt=""`
