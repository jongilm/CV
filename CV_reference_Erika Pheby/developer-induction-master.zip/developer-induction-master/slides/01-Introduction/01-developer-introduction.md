# Developer Induction
`Press S to see the notes`