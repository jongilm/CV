## Semantic markup ✔

![](images/immigration-status.jpg)
<iframe class="ace stretch" data-mode="html"><fieldset>
  <legend>Has your immigration status changed?</legend>
  <label for="immigration-Yes">
    <input type="radio" name="immigration" id="immigration-Yes" value="Yes">Yes
  </label>
  <label for="immigration-No">
    <input type="radio" name="immigration" id="immigration-No" value="No">No
  </label>
</fieldset></iframe>