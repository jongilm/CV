This directory will contain built Vagrant box files.
