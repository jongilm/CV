## Semantic markup ✖

![](images/immigration-status.jpg)
<iframe class="ace stretch" data-mode="html"><p>Has your immigration status changed?</p>
<input type="radio"><span>Yes</span>
<input type="radio"><span>No</span>
</iframe>