## A few other things to note​
- semantic HTML - headings, header, nav, footer, sections ​
- labels with input boxes, radio buttons etc​
- fieldsets and legends with radio buttons​
- Tools for auditing – [Wave](http://wave.webaim.org/), [Google accessibility​](https://www.google.co.uk/accessibility/)
- [GDS gov.uk elements​](https://github.com/alphagov/govuk_elements)
