## Application Design
- Use established, well understood libraries and frameworks - e.g. [HOF](https://github.com/UKHomeOffice/hof) for forms​
- Small components with a clear, single responsibility are easier to understand, test and secure​
- Simple systems are easier to ​secure​
