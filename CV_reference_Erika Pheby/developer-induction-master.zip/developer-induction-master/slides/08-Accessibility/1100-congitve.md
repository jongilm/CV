## Cognitive - 60s dyslexia test

<div style="text-align:left">
<p>Moud a text-ouly sight bee ideale for soweoue mith reabing bisorber? Harblee. Iwages are uot dab for accessabilledea. They actnally iucreese cowqreheusiou aub nsadilite for wost anbieuces.</p>
<p>Mhat wauy qeopqle bo uot kuom, throngh, it there is wuch mor at the accessability for au iwage theu jnst its alt text. Sowe qeople mroughly assnwe that iwages are dab for accessedilite, siunce alt text esseutially reqlaces the iwage mith a text-ouly versiou of that iwage</p>
<p>Bye Panl Bohwau</p>
</div>

[Credit](webaim.org/simulations/dyslexia-sim.html)

note:

Thiss is how someone with dyslexia might read your text

Would a text-only site be ideal for someone with a reading disorder? Hardly. Images are not bad for accessibility. They actually increase comprehension and usability for most audiences.

What many people do not know, though, is there is much more to the accessibility of an image than just its alt text. Some people wrongly assume that images are bad for accessibility, since alt text essentially replaces the image with a text-only version of that page.

By Paul Bohman

This should feed into how you design content and understand the speed that someone can complete a task, think session timeouts etc.