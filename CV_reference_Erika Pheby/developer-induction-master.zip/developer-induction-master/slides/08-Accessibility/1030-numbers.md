## 11m
people with a limiting long term illness, impairment, or disability
![](images/more-people.jpg)
