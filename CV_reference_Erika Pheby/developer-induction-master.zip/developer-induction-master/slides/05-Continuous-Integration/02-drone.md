## Drone
- Like TravisCI​
- Pipeline as code​
- Fully containerised​
- Integration with Github/Gitlab​
- Stateless​
- Not a Jenkins like-for-like replacement​
