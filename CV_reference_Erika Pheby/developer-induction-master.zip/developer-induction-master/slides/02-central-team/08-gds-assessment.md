## GDS assessment

- Assessors (50+)
- Consulting
- Engaged with GDS reshaping guidance