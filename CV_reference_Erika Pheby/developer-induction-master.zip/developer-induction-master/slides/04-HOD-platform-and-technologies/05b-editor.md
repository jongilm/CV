Dockerfile Editor
<iframe class="ace stretch" data-mode="dockerfile">FROM node:6-alpine
</iframe>