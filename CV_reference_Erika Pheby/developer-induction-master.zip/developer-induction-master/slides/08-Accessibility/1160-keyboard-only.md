## Keyboard only - focus style ✔
![](images/focus-style.jpg)