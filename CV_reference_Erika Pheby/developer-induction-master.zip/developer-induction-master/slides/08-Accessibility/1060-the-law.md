## It's the law

- [Equality Act 2010](http://www.legislation.gov.uk/ukpga/2010/15/contents)
- [Public Sector Equality Duty](https://www.gov.uk/guidance/equality-act-2010-guidance#public-sector-equality-duty)
- [Home Office Diversity Strategy](https://www.gov.uk/government/organisations/home-office/about/equality-and-diversity)
- HODDAT Targets
- [Service Assessments](https://www.gov.uk/service-manual/service-standard/create-a-service-thats-simple)