## Keyboard - TABINDEX going wrong

<video class="stretch" controls type="video/mp4" src="/media/tabbing.mp4">[A video of tabbing going wrong](https://www.youtube.com/v/Sqwm2B5yTXE)</video>