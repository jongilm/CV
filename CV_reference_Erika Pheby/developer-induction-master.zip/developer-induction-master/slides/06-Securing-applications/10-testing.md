## Security testing
- Penetration tests by external companies are performed for projects periodically
- We also do some automated security testing, guidance here:
  - http://bit.ly/2eCq6t3