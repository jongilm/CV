## Mission 4! Build in CI​

You will need the Drone docs... http://bit.ly/2hpHIc8
1. Create a public repo under `UKHomeOffice` org called `dsp-hello-world-yourname` 
   Where `yourname` is replaced with your name!
   This repo should be an exact copy of `dsp-hello-world`
1. Install the Drone CLI and activate your repository​ (see the docs above)
1. Make CI build your application whenever a new commit is pushed​
1. Publish a Docker image to Quay as part of your CI pipeline​