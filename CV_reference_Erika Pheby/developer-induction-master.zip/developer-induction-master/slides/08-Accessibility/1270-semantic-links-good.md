## Semantic links ✔
![](images/semantic-links-tick.jpg)